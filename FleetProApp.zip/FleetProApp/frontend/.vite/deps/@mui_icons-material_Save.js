"use client";
import { n as require_jsx_runtime, t as createSvgIcon } from "./createSvgIcon-CRMVhC13.js";
var Save_default = createSvgIcon(/* @__PURE__ */ (0, require_jsx_runtime().jsx)("path", { d: "M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3m3-10H5V5h10z" }), "Save");
//#endregion
export { Save_default as default };

//# sourceMappingURL=@mui_icons-material_Save.js.map