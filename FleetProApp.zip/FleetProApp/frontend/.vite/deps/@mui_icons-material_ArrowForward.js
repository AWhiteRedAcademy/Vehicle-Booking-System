"use client";
import { n as require_jsx_runtime, t as createSvgIcon } from "./createSvgIcon-CRMVhC13.js";
var ArrowForward_default = createSvgIcon(/* @__PURE__ */ (0, require_jsx_runtime().jsx)("path", { d: "m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z" }), "ArrowForward");
//#endregion
export { ArrowForward_default as default };

//# sourceMappingURL=@mui_icons-material_ArrowForward.js.map