"use client";
import { n as require_jsx_runtime, t as createSvgIcon } from "./createSvgIcon-CRMVhC13.js";
var MoreVert_default = createSvgIcon(/* @__PURE__ */ (0, require_jsx_runtime().jsx)("path", { d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2m0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2m0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2" }), "MoreVert");
//#endregion
export { MoreVert_default as default };

//# sourceMappingURL=@mui_icons-material_MoreVert.js.map