"use client";
import { n as require_jsx_runtime, t as createSvgIcon } from "./createSvgIcon-CRMVhC13.js";
var Edit_default = createSvgIcon(/* @__PURE__ */ (0, require_jsx_runtime().jsx)("path", { d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z" }), "Edit");
//#endregion
export { Edit_default as default };

//# sourceMappingURL=@mui_icons-material_Edit.js.map