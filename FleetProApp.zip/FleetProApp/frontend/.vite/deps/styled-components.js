import { r as __toESM, t as require_react } from "./react-DTjSBzeh.js";
import { t as isPropValid } from "./emotion-is-prop-valid.esm-a1jZC4cW.js";
//#region node_modules/stylis/src/Enum.js
var MS = "-ms-";
var MOZ = "-moz-";
var WEBKIT = "-webkit-";
var COMMENT = "comm";
var RULESET = "rule";
var DECLARATION = "decl";
var IMPORT = "@import";
var NAMESPACE = "@namespace";
var KEYFRAMES = "@keyframes";
var LAYER = "@layer";
//#endregion
//#region node_modules/stylis/src/Utility.js
/**
* @param {number}
* @return {number}
*/
var abs = Math.abs;
/**
* @param {number}
* @return {string}
*/
var from = String.fromCharCode;
/**
* @param {object}
* @return {object}
*/
var assign = Object.assign;
/**
* @param {string} value
* @param {number} length
* @return {number}
*/
function hash(value, length) {
	return charat(value, 0) ^ 45 ? (((length << 2 ^ charat(value, 0)) << 2 ^ charat(value, 1)) << 2 ^ charat(value, 2)) << 2 ^ charat(value, 3) : 0;
}
/**
* @param {string} value
* @return {string}
*/
function trim(value) {
	return value.trim();
}
/**
* @param {string} value
* @param {RegExp} pattern
* @return {string?}
*/
function match(value, pattern) {
	return (value = pattern.exec(value)) ? value[0] : value;
}
/**
* @param {string} value
* @param {(string|RegExp)} pattern
* @param {string} replacement
* @return {string}
*/
function replace(value, pattern, replacement) {
	return value.replace(pattern, replacement);
}
/**
* @param {string} value
* @param {string} search
* @param {number} position
* @return {number}
*/
function indexof(value, search, position) {
	return value.indexOf(search, position);
}
/**
* @param {string} value
* @param {number} index
* @return {number}
*/
function charat(value, index) {
	return value.charCodeAt(index) | 0;
}
/**
* @param {string} value
* @param {number} begin
* @param {number} end
* @return {string}
*/
function substr(value, begin, end) {
	return value.slice(begin, end);
}
/**
* @param {string} value
* @return {number}
*/
function strlen(value) {
	return value.length;
}
/**
* @param {any[]} value
* @return {number}
*/
function sizeof(value) {
	return value.length;
}
/**
* @param {any} value
* @param {any[]} array
* @return {any}
*/
function append(value, array) {
	return array.push(value), value;
}
/**
* @param {string[]} array
* @param {function} callback
* @return {string}
*/
function combine(array, callback) {
	return array.map(callback).join("");
}
/**
* @param {string[]} array
* @param {RegExp} pattern
* @return {string[]}
*/
function filter(array, pattern) {
	return array.filter(function(value) {
		return !match(value, pattern);
	});
}
//#endregion
//#region node_modules/stylis/src/Tokenizer.js
var line = 1;
var column = 1;
var length = 0;
var position = 0;
var character = 0;
var characters = "";
/**
* @param {string} value
* @param {object | null} root
* @param {object | null} parent
* @param {string} type
* @param {string[] | string} props
* @param {object[] | string} children
* @param {object[]} siblings
* @param {number} length
*/
function node(value, root, parent, type, props, children, length, siblings) {
	return {
		value,
		root,
		parent,
		type,
		props,
		children,
		line,
		column,
		length,
		return: "",
		siblings
	};
}
/**
* @param {object} root
* @param {object} props
* @return {object}
*/
function copy(root, props) {
	return assign(node("", null, null, "", null, null, 0, root.siblings), root, { length: -root.length }, props);
}
/**
* @param {object} root
*/
function lift(root) {
	while (root.root) root = copy(root.root, { children: [root] });
	append(root, root.siblings);
}
/**
* @return {number}
*/
function char() {
	return character;
}
/**
* @return {number}
*/
function prev() {
	character = position > 0 ? charat(characters, --position) : 0;
	if (column--, character === 10) column = 1, line--;
	return character;
}
/**
* @return {number}
*/
function next() {
	character = position < length ? charat(characters, position++) : 0;
	if (column++, character === 10) column = 1, line++;
	return character;
}
/**
* @return {number}
*/
function peek() {
	return charat(characters, position);
}
/**
* @return {number}
*/
function caret() {
	return position;
}
/**
* @param {number} begin
* @param {number} end
* @return {string}
*/
function slice(begin, end) {
	return substr(characters, begin, end);
}
/**
* @param {number} type
* @return {number}
*/
function token(type) {
	switch (type) {
		case 0:
		case 9:
		case 10:
		case 13:
		case 32: return 5;
		case 33:
		case 43:
		case 44:
		case 47:
		case 62:
		case 64:
		case 126:
		case 59:
		case 123:
		case 125: return 4;
		case 58: return 3;
		case 34:
		case 39:
		case 40:
		case 91: return 2;
		case 41:
		case 93: return 1;
	}
	return 0;
}
/**
* @param {string} value
* @return {any[]}
*/
function alloc(value) {
	return line = column = 1, length = strlen(characters = value), position = 0, [];
}
/**
* @param {any} value
* @return {any}
*/
function dealloc(value) {
	return characters = "", value;
}
/**
* @param {number} type
* @return {string}
*/
function delimit(type) {
	return trim(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)));
}
/**
* @param {number} type
* @return {string}
*/
function whitespace(type) {
	while (character = peek()) if (character < 33) next();
	else break;
	return token(type) > 2 || token(character) > 3 ? "" : " ";
}
/**
* @param {number} index
* @param {number} count
* @return {string}
*/
function escaping(index, count) {
	while (--count && next()) if (character < 48 || character > 102 || character > 57 && character < 65 || character > 70 && character < 97) break;
	return slice(index, caret() + (count < 6 && peek() == 32 && next() == 32));
}
/**
* @param {number} type
* @return {number}
*/
function delimiter(type) {
	while (next()) switch (character) {
		case type: return position;
		case 34:
		case 39:
			if (type !== 34 && type !== 39) delimiter(character);
			break;
		case 40:
			if (type === 41) delimiter(type);
			break;
		case 92:
			next();
			break;
	}
	return position;
}
/**
* @param {number} type
* @param {number} index
* @return {number}
*/
function commenter(type, index) {
	while (next()) if (type + character === 57) break;
	else if (type + character === 84 && peek() === 47) break;
	return "/*" + slice(index, position - 1) + "*" + from(type === 47 ? type : next());
}
/**
* @param {number} index
* @return {string}
*/
function identifier(index) {
	while (!token(peek())) next();
	return slice(index, position);
}
//#endregion
//#region node_modules/stylis/src/Parser.js
/**
* @param {string} value
* @return {object[]}
*/
function compile(value) {
	return dealloc(parse("", null, null, null, [""], value = alloc(value), 0, [0], value));
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {string[]} rule
* @param {string[]} rules
* @param {string[]} rulesets
* @param {number[]} pseudo
* @param {number[]} points
* @param {string[]} declarations
* @return {object}
*/
function parse(value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
	var index = 0;
	var offset = 0;
	var length = pseudo;
	var atrule = 0;
	var property = 0;
	var previous = 0;
	var variable = 1;
	var scanning = 1;
	var ampersand = 1;
	var character = 0;
	var type = "";
	var props = rules;
	var children = rulesets;
	var reference = rule;
	var characters = type;
	while (scanning) switch (previous = character, character = next()) {
		case 40: if (previous != 108 && charat(characters, length - 1) == 58) {
			if (indexof(characters += replace(delimit(character), "&", "&\f"), "&\f", abs(index ? points[index - 1] : 0)) != -1) ampersand = -1;
			break;
		}
		case 34:
		case 39:
		case 91:
			characters += delimit(character);
			break;
		case 9:
		case 10:
		case 13:
		case 32:
			characters += whitespace(previous);
			break;
		case 92:
			characters += escaping(caret() - 1, 7);
			continue;
		case 47:
			switch (peek()) {
				case 42:
				case 47:
					append(comment(commenter(next(), caret()), root, parent, declarations), declarations);
					if ((token(previous || 1) == 5 || token(peek() || 1) == 5) && strlen(characters) && substr(characters, -1, void 0) !== " ") characters += " ";
					break;
				default: characters += "/";
			}
			break;
		case 123 * variable: points[index++] = strlen(characters) * ampersand;
		case 125 * variable:
		case 59:
		case 0:
			switch (character) {
				case 0:
				case 125: scanning = 0;
				case 59 + offset:
					if (ampersand == -1) characters = replace(characters, /\f/g, "");
					if (property > 0 && (strlen(characters) - length || variable === 0 && previous === 47)) append(property > 32 ? declaration(characters + ";", rule, parent, length - 1, declarations) : declaration(replace(characters, " ", "") + ";", rule, parent, length - 2, declarations), declarations);
					break;
				case 59: characters += ";";
				default:
					append(reference = ruleset(characters, root, parent, index, offset, rules, points, type, props = [], children = [], length, rulesets), rulesets);
					if (character === 123) if (offset === 0) parse(characters, root, reference, reference, props, rulesets, length, points, children);
					else {
						switch (atrule) {
							case 99: if (charat(characters, 3) === 110) break;
							case 108: if (charat(characters, 2) === 97) break;
							default: offset = 0;
							case 100:
							case 109:
							case 115:
						}
						if (offset) parse(value, reference, reference, rule && append(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length, children), children), rules, children, length, points, rule ? props : children);
						else parse(characters, reference, reference, reference, [""], children, 0, points, children);
					}
			}
			index = offset = property = 0, variable = ampersand = 1, type = characters = "", length = pseudo;
			break;
		case 58: length = 1 + strlen(characters), property = previous;
		default:
			if (variable < 1) {
				if (character == 123) --variable;
				else if (character == 125 && variable++ == 0 && prev() == 125) continue;
			}
			switch (characters += from(character), character * variable) {
				case 38:
					ampersand = offset > 0 ? 1 : (characters += "\f", -1);
					break;
				case 44:
					points[index++] = (strlen(characters) - 1) * ampersand, ampersand = 1;
					break;
				case 64:
					if (peek() === 45) characters += delimit(next());
					atrule = peek(), offset = length = strlen(type = characters += identifier(caret())), character++;
					break;
				case 45: if (previous === 45 && strlen(characters) == 2) variable = 0;
			}
	}
	return rulesets;
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {number} index
* @param {number} offset
* @param {string[]} rules
* @param {number[]} points
* @param {string} type
* @param {string[]} props
* @param {string[]} children
* @param {number} length
* @param {object[]} siblings
* @return {object}
*/
function ruleset(value, root, parent, index, offset, rules, points, type, props, children, length, siblings) {
	var post = offset - 1;
	var rule = offset === 0 ? rules : [""];
	var size = sizeof(rule);
	for (var i = 0, j = 0, k = 0; i < index; ++i) for (var x = 0, y = substr(value, post + 1, post = abs(j = points[i])), z = value; x < size; ++x) if (z = trim(j > 0 ? rule[x] + " " + y : replace(y, /&\f/g, rule[x]))) props[k++] = z;
	return node(value, root, parent, offset === 0 ? RULESET : type, props, children, length, siblings);
}
/**
* @param {number} value
* @param {object} root
* @param {object?} parent
* @param {object[]} siblings
* @return {object}
*/
function comment(value, root, parent, siblings) {
	return node(value, root, parent, COMMENT, from(char()), substr(value, 2, -2), 0, siblings);
}
/**
* @param {string} value
* @param {object} root
* @param {object?} parent
* @param {number} length
* @param {object[]} siblings
* @return {object}
*/
function declaration(value, root, parent, length, siblings) {
	return node(value, root, parent, DECLARATION, substr(value, 0, length), substr(value, length + 1, -1), length, siblings);
}
//#endregion
//#region node_modules/stylis/src/Prefixer.js
/**
* @param {string} value
* @param {number} length
* @param {object[]} children
* @return {string}
*/
function prefix(value, length, children) {
	switch (hash(value, length)) {
		case 5103: return WEBKIT + "print-" + value + value;
		case 5737:
		case 4201:
		case 3177:
		case 3433:
		case 1641:
		case 4457:
		case 2921:
		case 5572:
		case 6356:
		case 5844:
		case 3191:
		case 6645:
		case 3005:
		case 4215:
		case 6389:
		case 5109:
		case 5365:
		case 5621:
		case 3829:
		case 6391:
		case 5879:
		case 5623:
		case 6135:
		case 4599: return WEBKIT + value + value;
		case 4855: return WEBKIT + value.replace("add", "source-over").replace("substract", "source-out").replace("intersect", "source-in").replace("exclude", "xor") + value;
		case 4789: return MOZ + value + value;
		case 5349:
		case 4246:
		case 4810:
		case 6968:
		case 2756: return WEBKIT + value + MOZ + value + MS + value + value;
		case 5936: switch (charat(value, length + 11)) {
			case 114: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb") + value;
			case 108: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb-rl") + value;
			case 45: return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "lr") + value;
		}
		case 6828:
		case 4268:
		case 2903: return WEBKIT + value + MS + value + value;
		case 6165: return WEBKIT + value + MS + "flex-" + value + value;
		case 5187: return WEBKIT + value + replace(value, /(\w+).+(:[^]+)/, WEBKIT + "box-$1$2" + MS + "flex-$1$2") + value;
		case 5443: return WEBKIT + value + MS + "flex-item-" + replace(value, /flex-|-self/g, "") + (!match(value, /flex-|baseline/) ? MS + "grid-row-" + replace(value, /flex-|-self/g, "") : "") + value;
		case 4675: return WEBKIT + value + MS + "flex-line-pack" + replace(value, /align-content|flex-|-self/g, "") + value;
		case 5548: return WEBKIT + value + MS + replace(value, "shrink", "negative") + value;
		case 5292: return WEBKIT + value + MS + replace(value, "basis", "preferred-size") + value;
		case 6060: return WEBKIT + "box-" + replace(value, "-grow", "") + WEBKIT + value + MS + replace(value, "grow", "positive") + value;
		case 4554: return WEBKIT + replace(value, /([^-])(transform)/g, "$1" + WEBKIT + "$2") + value;
		case 6187: return replace(replace(replace(value, /(zoom-|grab)/, WEBKIT + "$1"), /(image-set)/, WEBKIT + "$1"), value, "") + value;
		case 5495:
		case 3959: return replace(value, /(image-set\([^]*)/, WEBKIT + "$1$`$1");
		case 4968: return replace(replace(value, /(.+:)(flex-)?(.*)/, WEBKIT + "box-pack:$3" + MS + "flex-pack:$3"), /space-between/, "justify") + WEBKIT + value + value;
		case 4200:
			if (!match(value, /flex-|baseline/)) return MS + "grid-column-align" + substr(value, length) + value;
			break;
		case 2592:
		case 3360: return MS + replace(value, "template-", "") + value;
		case 4384:
		case 3616:
			if (children && children.some(function(element, index) {
				return length = index, match(element.props, /grid-\w+-end/);
			})) return ~indexof(value + (children = children[length].value), "span", 0) ? value : MS + replace(value, "-start", "") + value + MS + "grid-row-span:" + (~indexof(children, "span", 0) ? match(children, /\d+/) : +match(children, /\d+/) - +match(value, /\d+/)) + ";";
			return MS + replace(value, "-start", "") + value;
		case 4896:
		case 4128: return children && children.some(function(element) {
			return match(element.props, /grid-\w+-start/);
		}) ? value : MS + replace(replace(value, "-end", "-span"), "span ", "") + value;
		case 4095:
		case 3583:
		case 4068:
		case 2532: return replace(value, /(.+)-inline(.+)/, WEBKIT + "$1$2") + value;
		case 8116:
		case 7059:
		case 5753:
		case 5535:
		case 5445:
		case 5701:
		case 4933:
		case 4677:
		case 5533:
		case 5789:
		case 5021:
		case 4765:
			if (strlen(value) - 1 - length > 6) switch (charat(value, length + 1)) {
				case 109: if (charat(value, length + 4) !== 45) break;
				case 102: return replace(value, /(.+:)(.+)-([^]+)/, "$1" + WEBKIT + "$2-$3$1" + MOZ + (charat(value, length + 3) == 108 ? "$3" : "$2-$3")) + value;
				case 115: return ~indexof(value, "stretch", 0) ? prefix(replace(value, "stretch", "fill-available"), length, children) + value : value;
			}
			break;
		case 5152:
		case 5920: return replace(value, /(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/, function(_, a, b, c, d, e, f) {
			return MS + a + ":" + b + f + (c ? MS + a + "-span:" + (d ? e : +e - +b) + f : "") + value;
		});
		case 4949:
			if (charat(value, length + 6) === 121) return replace(value, ":", ":" + WEBKIT) + value;
			break;
		case 6444:
			switch (charat(value, charat(value, 14) === 45 ? 18 : 11)) {
				case 120: return replace(value, /(.+:)([^;\s!]+)(;|(\s+)?!.+)?/, "$1" + WEBKIT + (charat(value, 14) === 45 ? "inline-" : "") + "box$3$1" + WEBKIT + "$2$3$1" + MS + "$2box$3") + value;
				case 100: return replace(value, ":", ":" + MS) + value;
			}
			break;
		case 5719:
		case 2647:
		case 2135:
		case 3927:
		case 2391: return replace(value, "scroll-", "scroll-snap-") + value;
	}
	return value;
}
//#endregion
//#region node_modules/stylis/src/Serializer.js
/**
* @param {object[]} children
* @param {function} callback
* @return {string}
*/
function serialize(children, callback) {
	var output = "";
	for (var i = 0; i < children.length; i++) output += callback(children[i], i, children, callback) || "";
	return output;
}
/**
* @param {object} element
* @param {number} index
* @param {object[]} children
* @param {function} callback
* @return {string}
*/
function stringify(element, index, children, callback) {
	switch (element.type) {
		case LAYER: if (element.children.length) break;
		case IMPORT:
		case NAMESPACE:
		case DECLARATION: return element.return = element.return || element.value;
		case COMMENT: return "";
		case KEYFRAMES: return element.return = element.value + "{" + serialize(element.children, callback) + "}";
		case RULESET: if (!strlen(element.value = element.props.join(","))) return "";
	}
	return strlen(children = serialize(element.children, callback)) ? element.return = element.value + "{" + children + "}" : "";
}
//#endregion
//#region node_modules/stylis/src/Middleware.js
/**
* @param {function[]} collection
* @return {function}
*/
function middleware(collection) {
	var length = sizeof(collection);
	return function(element, index, children, callback) {
		var output = "";
		for (var i = 0; i < length; i++) output += collection[i](element, index, children, callback) || "";
		return output;
	};
}
/**
* @param {function} callback
* @return {function}
*/
function rulesheet(callback) {
	return function(element) {
		if (!element.root) {
			if (element = element.return) callback(element);
		}
	};
}
/**
* @param {object} element
* @param {number} index
* @param {object[]} children
* @param {function} callback
*/
function prefixer(element, index, children, callback) {
	if (element.length > -1) {
		if (!element.return) switch (element.type) {
			case DECLARATION:
				element.return = prefix(element.value, element.length, children);
				return;
			case KEYFRAMES: return serialize([copy(element, { value: replace(element.value, "@", "@" + WEBKIT) })], callback);
			case RULESET: if (element.length) return combine(children = element.props, function(value) {
				switch (match(value, callback = /(::plac\w+|:read-\w+)/)) {
					case ":read-only":
					case ":read-write":
						lift(copy(element, { props: [replace(value, /:(read-\w+)/, ":" + MOZ + "$1")] }));
						lift(copy(element, { props: [value] }));
						assign(element, { props: filter(children, callback) });
						break;
					case "::placeholder":
						lift(copy(element, { props: [replace(value, /:(plac\w+)/, ":" + WEBKIT + "input-$1")] }));
						lift(copy(element, { props: [replace(value, /:(plac\w+)/, ":" + MOZ + "$1")] }));
						lift(copy(element, { props: [replace(value, /:(plac\w+)/, MS + "input-$1")] }));
						lift(copy(element, { props: [value] }));
						assign(element, { props: filter(children, callback) });
						break;
				}
				return "";
			});
		}
	}
}
//#endregion
//#region node_modules/styled-components/dist/styled-components.browser.esm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var r, i;
var c = "undefined" != typeof process && void 0 !== process.env && (process.env.REACT_APP_SC_ATTR || process.env.SC_ATTR) || "data-styled", a = "active", l = "data-styled-version", u = "6.4.1", h = "/*!sc*/\n", d = "undefined" != typeof window && "undefined" != typeof document;
function p(e) {
	if ("undefined" != typeof process && void 0 !== process.env) {
		const t = process.env[e];
		if (void 0 !== t && "" !== t) return "false" !== t;
	}
}
var f = Boolean("boolean" == typeof SC_DISABLE_SPEEDY ? SC_DISABLE_SPEEDY : null !== (i = null !== (r = p("REACT_APP_SC_DISABLE_SPEEDY")) && void 0 !== r ? r : p("SC_DISABLE_SPEEDY")) && void 0 !== i ? i : "undefined" == typeof process || void 0 === process.env || true), m = "sc-keyframes-", y = {}, g = {
	1: "Cannot create styled-component for component: %s.\n\n",
	2: "Can't collect styles once you've consumed a `ServerStyleSheet`'s styles! `ServerStyleSheet` is a one off instance for each server-side render cycle.\n\n- Are you trying to reuse it across renders?\n- Are you accidentally calling collectStyles twice?\n\n",
	3: "Streaming SSR is only supported in a Node.js environment; Please do not try to call this method in the browser.\n\n",
	4: "The `StyleSheetManager` expects a valid target or sheet prop!\n\n- Does this error occur on the client and is your target falsy?\n- Does this error occur on the server and is the sheet falsy?\n\n",
	5: "The clone method cannot be used on the client!\n\n- Are you running in a client-like environment on the server?\n- Are you trying to run SSR on the client?\n\n",
	6: "Trying to insert a new style tag, but the given Node is unmounted!\n\n- Are you using a custom target that isn't mounted?\n- Does your document not have a valid head element?\n- Have you accidentally removed a style tag manually?\n\n",
	7: "ThemeProvider: Please return an object from your \"theme\" prop function, e.g.\n\n```js\ntheme={() => ({})}\n```\n\n",
	8: "ThemeProvider: Please make your \"theme\" prop an object.\n\n",
	9: "Missing document `<head>`\n\n",
	10: "Cannot find a StyleSheet instance. Usually this happens if there are multiple copies of styled-components loaded at once. Check out this issue for how to troubleshoot and fix the common cases where this situation can happen: https://github.com/styled-components/styled-components/issues/1941#issuecomment-417862021\n\n",
	11: "_This error was replaced with a dev-time warning, it will be deleted for v4 final._ [createGlobalStyle] received children which will not be rendered. Please use the component without passing children elements.\n\n",
	12: "It seems you are interpolating a keyframe declaration (%s) into an untagged string. Please wrap your string in the css\\`\\` helper which ensures the styles are injected correctly. See https://styled-components.com/docs/api#css\n\n",
	13: "%s is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.\n\n",
	14: "ThemeProvider: \"theme\" prop is required.\n\n",
	15: "A stylis plugin has been supplied that is not named. We need a name for each plugin to be able to prevent styling collisions between different stylis configurations within the same app. Before you pass your plugin to `<StyleSheetManager stylisPlugins={[]}>`, please make sure each plugin is uniquely-named, e.g.\n\n```js\nObject.defineProperty(importedPlugin, 'name', { value: 'some-unique-name' });\n```\n\n",
	16: "Reached the limit of how many styled components may be created at group %s.\nYou may only create up to 1,073,741,824 components. If you're creating components dynamically,\nas for instance in your render method then you may be running into this limitation.\n\n",
	17: "CSSStyleSheet could not be found on HTMLStyleElement.\nHas styled-components' style tag been unmounted or altered by another script?\n\n",
	18: "Accessing `useTheme` hook outside of a `<ThemeProvider>` element.\n\n```jsx\nimport { useTheme } from 'styled-components';\nexport function StyledCompoent({ children }) {\n  const theme = useTheme();\n  return <div style={{ width: theme.sizes.full }}>{children}</div>;\n}\n\nimport { StyledComponent } from './StyledComponent';\nimport { theme } from './theme';\nexport function App() {\n  return (\n    <ThemeProvider theme={theme}>\n      <StyledComponent />\n    </ThemeProvider>\n  );\n}\n```\n\nIf you need access to the theme in an uncertain composition scenario, `React.useContext(ThemeContext)` will not emit an error if there is no `ThemeProvider` ancestor.\n"
};
function v(e, ...t) {
	return new Error(function(...e) {
		let t = e[0];
		const n = [];
		for (let t = 1, o = e.length; t < o; t += 1) n.push(e[t]);
		return n.forEach((e) => {
			t = t.replace(/%[a-z]/, e);
		}), t;
	}(g[e], ...t).trim());
}
var S = 1 << 30;
var b = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Map(), N = 1;
var C = (e) => {
	if (b.has(e)) return b.get(e);
	for (; w.has(N);) N++;
	const t = N++;
	if ((0 | t) < 0 || t > S) throw v(16, `${t}`);
	return b.set(e, t), w.set(t, e), t;
}, O = (e) => w.get(e), E = (e, t) => {
	N = t + 1, b.set(e, t), w.set(t, e);
}, A = /invalid hook call/i, P = /* @__PURE__ */ new Set(), _ = (e, n) => {
	{
		const o = `The component ${e}${n ? ` with the id of "${n}"` : ""} has been created dynamically.\nYou may see this warning because you've called styled inside another component.\nTo resolve this only create new StyledComponents outside of any render method and function component.\nSee https://styled-components.com/docs/basics#define-styled-components-outside-of-the-render-method for more info.\n`, s = console.error;
		try {
			let e = !0;
			console.error = (t, ...n) => {
				A.test(t) ? (e = !1, P.delete(o)) : s(t, ...n);
			}, "function" == typeof import_react.useState && import_react.useState(null), e && !P.has(o) && (console.warn(o), P.add(o));
		} catch (e) {
			A.test(e.message) && P.delete(o);
		} finally {
			console.error = s;
		}
	}
}, I = Object.freeze([]), $ = Object.freeze({});
function R(e, t, n = $) {
	return e.theme !== n.theme && e.theme || t || n.theme;
}
var j = /[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g, x = /(^-|-$)/g;
function T(e) {
	return e.replace(j, "-").replace(x, "");
}
var k = /(a)(d)/gi, D = (e) => String.fromCharCode(e + (e > 25 ? 39 : 97));
function V(e) {
	let t, n = "";
	for (t = Math.abs(e); t > 52; t = t / 52 | 0) n = D(t % 52) + n;
	return (D(t % 52) + n).replace(k, "$1-$2");
}
var M = 5381, G = (e, t) => {
	let n = t.length;
	for (; n;) e = 33 * e ^ t.charCodeAt(--n);
	return e;
}, F = (e) => G(M, e);
function z(e) {
	return V(F(e) >>> 0);
}
function W(e) {
	return "string" == typeof e && e || e.displayName || e.name || "Component";
}
function L(e) {
	return "string" == typeof e && e.charAt(0) === e.charAt(0).toLowerCase();
}
function B(e) {
	return L(e) ? `styled.${e}` : `Styled(${W(e)})`;
}
var q = Symbol.for("react.memo"), H = Symbol.for("react.forward_ref"), Y = {
	contextType: !0,
	defaultProps: !0,
	displayName: !0,
	getDerivedStateFromError: !0,
	getDerivedStateFromProps: !0,
	propTypes: !0,
	type: !0
}, U = {
	name: !0,
	length: !0,
	prototype: !0,
	caller: !0,
	callee: !0,
	arguments: !0,
	arity: !0
}, J = {
	$$typeof: !0,
	compare: !0,
	defaultProps: !0,
	displayName: !0,
	propTypes: !0,
	type: !0
}, X = {
	[H]: {
		$$typeof: !0,
		render: !0,
		defaultProps: !0,
		displayName: !0,
		propTypes: !0
	},
	[q]: J
};
function K(e) {
	return ("type" in (t = e) && t.type.$$typeof) === q ? J : "$$typeof" in e ? X[e.$$typeof] : Y;
	var t;
}
var Q = Object.defineProperty, Z = Object.getOwnPropertyNames, ee = Object.getOwnPropertySymbols, te = Object.getOwnPropertyDescriptor, ne = Object.getPrototypeOf, oe = Object.prototype;
function se(e, t, n) {
	if ("string" != typeof t) {
		const o = ne(t);
		o && o !== oe && se(e, o, n);
		const s = Z(t).concat(ee(t)), r = K(e), i = K(t);
		for (let o = 0; o < s.length; ++o) {
			const c = s[o];
			if (!(c in U || n && n[c] || i && c in i || r && c in r)) {
				const n = te(t, c);
				try {
					Q(e, c, n);
				} catch (e) {}
			}
		}
	}
	return e;
}
function re(e) {
	return "function" == typeof e;
}
function ie(e) {
	return "object" == typeof e && "styledComponentId" in e;
}
function ce(e, t) {
	return e && t ? e + " " + t : e || t || "";
}
function ae(e, t) {
	return e.join(t || "");
}
function le(e) {
	return null !== e && "object" == typeof e && e.constructor.name === Object.name && !("props" in e && e.$$typeof);
}
function ue(e, t, n = !1) {
	if (!n && !le(e) && !Array.isArray(e)) return t;
	if (Array.isArray(t)) for (let n = 0; n < t.length; n++) e[n] = ue(e[n], t[n]);
	else if (le(t)) for (const n in t) e[n] = ue(e[n], t[n]);
	return e;
}
function he(e, t) {
	Object.defineProperty(e, "toString", { value: t });
}
var de = class {
	constructor(e) {
		this.groupSizes = new Uint32Array(512), this.length = 512, this.tag = e, this._cGroup = 0, this._cIndex = 0;
	}
	indexOfGroup(e) {
		if (e === this._cGroup) return this._cIndex;
		let t = this._cIndex;
		if (e > this._cGroup) for (let n = this._cGroup; n < e; n++) t += this.groupSizes[n];
		else for (let n = this._cGroup - 1; n >= e; n--) t -= this.groupSizes[n];
		return this._cGroup = e, this._cIndex = t, t;
	}
	insertRules(e, t) {
		if (e >= this.groupSizes.length) {
			const t = this.groupSizes, n = t.length;
			let o = n;
			for (; e >= o;) if (o <<= 1, o < 0) throw v(16, `${e}`);
			this.groupSizes = new Uint32Array(o), this.groupSizes.set(t), this.length = o;
			for (let e = n; e < o; e++) this.groupSizes[e] = 0;
		}
		let n = this.indexOfGroup(e + 1), o = 0;
		for (let s = 0, r = t.length; s < r; s++) this.tag.insertRule(n, t[s]) && (this.groupSizes[e]++, n++, o++);
		o > 0 && this._cGroup > e && (this._cIndex += o);
	}
	clearGroup(e) {
		if (e < this.length) {
			const t = this.groupSizes[e], n = this.indexOfGroup(e), o = n + t;
			this.groupSizes[e] = 0;
			for (let e = n; e < o; e++) this.tag.deleteRule(n);
			t > 0 && this._cGroup > e && (this._cIndex -= t);
		}
	}
	getGroup(e) {
		let t = "";
		if (e >= this.length || 0 === this.groupSizes[e]) return t;
		const n = this.groupSizes[e], o = this.indexOfGroup(e), s = o + n;
		for (let e = o; e < s; e++) t += this.tag.getRule(e) + h;
		return t;
	}
}, pe = `style[${c}][${l}="${u}"]`, fe = new RegExp(`^${c}\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)`), me = (e) => "undefined" != typeof ShadowRoot && e instanceof ShadowRoot || "host" in e && 11 === e.nodeType, ye = (e) => {
	if (!e) return document;
	if (me(e)) return e;
	if ("getRootNode" in e) {
		const t = e.getRootNode();
		if (me(t)) return t;
	}
	return document;
}, ge = (e, t, n) => {
	const o = n.split(",");
	let s;
	for (let n = 0, r = o.length; n < r; n++) (s = o[n]) && e.registerName(t, s);
}, ve = (e, t) => {
	var n;
	const o = (null !== (n = t.textContent) && void 0 !== n ? n : "").split(h), s = [];
	for (let t = 0, n = o.length; t < n; t++) {
		const n = o[t].trim();
		if (!n) continue;
		const r = n.match(fe);
		if (r) {
			const t = 0 | parseInt(r[1], 10), n = r[2];
			0 !== t && (E(n, t), ge(e, n, r[3]), e.getTag().insertRules(t, s)), s.length = 0;
		} else s.push(n);
	}
}, Se = (e) => {
	const t = ye(e.options.target).querySelectorAll(pe);
	for (let n = 0, o = t.length; n < o; n++) {
		const o = t[n];
		o && o.getAttribute(c) !== a && (ve(e, o), o.parentNode && o.parentNode.removeChild(o));
	}
};
var be = !1;
function we() {
	if (!1 !== be) return be;
	if ("undefined" != typeof document) {
		const e = document.head.querySelector("meta[property=\"csp-nonce\"]");
		if (e) return be = e.nonce || e.getAttribute("content") || void 0;
		const t = document.head.querySelector("meta[name=\"sc-nonce\"]");
		if (t) return be = t.getAttribute("content") || void 0;
	}
	return be = "undefined" != typeof __webpack_nonce__ ? __webpack_nonce__ : void 0;
}
var Ne = (e, t) => {
	const n = document.head, o = e || n, s = document.createElement("style"), r = ((e) => {
		const t = Array.from(e.querySelectorAll(`style[${c}]`));
		return t[t.length - 1];
	})(o), i = void 0 !== r ? r.nextSibling : null;
	s.setAttribute(c, a), s.setAttribute(l, u);
	const h = t || we();
	return h && s.setAttribute("nonce", h), o.insertBefore(s, i), s;
}, Ce = class {
	constructor(e, t) {
		this.element = Ne(e, t), this.element.appendChild(document.createTextNode("")), this.sheet = ((e) => {
			var t;
			if (e.sheet) return e.sheet;
			const n = null !== (t = e.getRootNode().styleSheets) && void 0 !== t ? t : document.styleSheets;
			for (let t = 0, o = n.length; t < o; t++) {
				const o = n[t];
				if (o.ownerNode === e) return o;
			}
			throw v(17);
		})(this.element), this.length = 0;
	}
	insertRule(e, t) {
		try {
			return this.sheet.insertRule(t, e), this.length++, !0;
		} catch (e) {
			return !1;
		}
	}
	deleteRule(e) {
		this.sheet.deleteRule(e), this.length--;
	}
	getRule(e) {
		const t = this.sheet.cssRules[e];
		return t && t.cssText ? t.cssText : "";
	}
}, Oe = class {
	constructor(e, t) {
		this.element = Ne(e, t), this.nodes = this.element.childNodes, this.length = 0;
	}
	insertRule(e, t) {
		if (e <= this.length && e >= 0) {
			const n = document.createTextNode(t);
			return this.element.insertBefore(n, this.nodes[e] || null), this.length++, !0;
		}
		return !1;
	}
	deleteRule(e) {
		this.element.removeChild(this.nodes[e]), this.length--;
	}
	getRule(e) {
		return e < this.length ? this.nodes[e].textContent : "";
	}
};
var Ee = d;
var Ae = {
	isServer: !d,
	useCSSOMInjection: !f
};
var Pe = class Pe {
	static registerId(e) {
		return C(e);
	}
	constructor(e = $, t = {}, n) {
		this.options = Object.assign(Object.assign({}, Ae), e), this.gs = t, this.keyframeIds = /* @__PURE__ */ new Set(), this.names = new Map(n), this.server = !!e.isServer, !this.server && d && Ee && (Ee = !1, Se(this)), he(this, () => ((e) => {
			const t = e.getTag(), { length: n } = t;
			let o = "";
			for (let s = 0; s < n; s++) {
				const n = O(s);
				if (void 0 === n) continue;
				const r = e.names.get(n);
				if (void 0 === r || !r.size) continue;
				const i = t.getGroup(s);
				if (0 === i.length) continue;
				const a = c + ".g" + s + "[id=\"" + n + "\"]";
				let l = "";
				for (const e of r) e.length > 0 && (l += e + ",");
				o += i + a + "{content:\"" + l + "\"}/*!sc*/\n";
			}
			return o;
		})(this));
	}
	rehydrate() {
		!this.server && d && Se(this);
	}
	reconstructWithOptions(e, t = !0) {
		const n = new Pe(Object.assign(Object.assign({}, this.options), e), this.gs, t && this.names || void 0);
		return n.keyframeIds = new Set(this.keyframeIds), !this.server && d && e.target !== this.options.target && ye(this.options.target) !== ye(e.target) && Se(n), n;
	}
	allocateGSInstance(e) {
		return this.gs[e] = (this.gs[e] || 0) + 1;
	}
	getTag() {
		return this.tag || (this.tag = (e = (({ useCSSOMInjection: e, target: t, nonce: n }) => e ? new Ce(t, n) : new Oe(t, n))(this.options), new de(e)));
		var e;
	}
	hasNameForId(e, t) {
		var n, o;
		return null !== (o = null === (n = this.names.get(e)) || void 0 === n ? void 0 : n.has(t)) && void 0 !== o && o;
	}
	registerName(e, t) {
		C(e), e.startsWith(m) && this.keyframeIds.add(e);
		const n = this.names.get(e);
		n ? n.add(t) : this.names.set(e, new Set([t]));
	}
	insertRules(e, t, n) {
		this.registerName(e, t), this.getTag().insertRules(C(e), n);
	}
	clearNames(e) {
		this.names.has(e) && this.names.get(e).clear();
	}
	clearRules(e) {
		this.getTag().clearGroup(C(e)), this.clearNames(e);
	}
	clearTag() {
		this.tag = void 0;
	}
};
var _e = /* @__PURE__ */ new WeakSet(), Ie = {
	animationIterationCount: 1,
	aspectRatio: 1,
	borderImageOutset: 1,
	borderImageSlice: 1,
	borderImageWidth: 1,
	columnCount: 1,
	columns: 1,
	flex: 1,
	flexGrow: 1,
	flexShrink: 1,
	gridRow: 1,
	gridRowEnd: 1,
	gridRowSpan: 1,
	gridRowStart: 1,
	gridColumn: 1,
	gridColumnEnd: 1,
	gridColumnSpan: 1,
	gridColumnStart: 1,
	fontWeight: 1,
	lineHeight: 1,
	opacity: 1,
	order: 1,
	orphans: 1,
	scale: 1,
	tabSize: 1,
	widows: 1,
	zIndex: 1,
	zoom: 1,
	WebkitLineClamp: 1,
	fillOpacity: 1,
	floodOpacity: 1,
	stopOpacity: 1,
	strokeDasharray: 1,
	strokeDashoffset: 1,
	strokeMiterlimit: 1,
	strokeOpacity: 1,
	strokeWidth: 1
};
function $e(e, t) {
	return null == t || "boolean" == typeof t || "" === t ? "" : "number" != typeof t || 0 === t || e in Ie || e.startsWith("--") ? String(t).trim() : t + "px";
}
var Re = 47;
function je(e) {
	if (45 === e.charCodeAt(0) && 45 === e.charCodeAt(1)) return e;
	let t = "";
	for (let n = 0; n < e.length; n++) {
		const o = e.charCodeAt(n);
		t += o >= 65 && o <= 90 ? "-" + String.fromCharCode(o + 32) : e[n];
	}
	return t.startsWith("ms-") ? "-" + t : t;
}
var xe = Symbol.for("sc-keyframes");
function Te(e) {
	return "object" == typeof e && null !== e && xe in e;
}
function ke(e) {
	return re(e) && !(e.prototype && e.prototype.isReactComponent);
}
var De = (e) => null == e || !1 === e || "" === e, Ve = Symbol.for("react.client.reference");
function Me(e) {
	return e.$$typeof === Ve;
}
function Ge(e) {
	const t = e.$$id, n = (t && t.includes("#") ? t.split("#").pop() : t) || e.name || "unknown";
	console.warn(`Interpolating a client component (${n}) as a selector is not supported in server components. The component selector pattern requires access to the component's internal class name, which is not available across the server/client boundary. Use a plain CSS class selector instead.`);
}
function Fe(e, t) {
	for (const n in e) {
		const o = e[n];
		e.hasOwnProperty(n) && !De(o) && (Array.isArray(o) && _e.has(o) || re(o) ? t.push(je(n) + ":", o, ";") : le(o) ? (t.push(n + " {"), Fe(o, t), t.push("}")) : t.push(je(n) + ": " + $e(n, o) + ";"));
	}
}
function ze(e, t, n, o, s = []) {
	if (De(e)) return s;
	const r = typeof e;
	if ("string" === r) return s.push(e), s;
	if ("function" === r) {
		if (Me(e)) return Ge(e), s;
		if (ke(e) && t) {
			const r = e(t);
			return "object" != typeof r || Array.isArray(r) || Te(r) || le(r) || null === r || console.error(`${W(e)} is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.`), ze(r, t, n, o, s);
		}
		return s.push(e), s;
	}
	if (Array.isArray(e)) {
		for (let r = 0; r < e.length; r++) ze(e[r], t, n, o, s);
		return s;
	}
	return ie(e) ? (s.push(`.${e.styledComponentId}`), s) : Te(e) ? (n ? (e.inject(n, o), s.push(e.getName(o))) : s.push(e), s) : Me(e) ? (Ge(e), s) : le(e) ? (Fe(e, s), s) : (s.push(e.toString()), s);
}
var We = F(u);
var Le = class {
	constructor(e, t, n) {
		this.rules = e, this.componentId = t, this.baseHash = G(We, t), this.baseStyle = n, Pe.registerId(t);
	}
	generateAndInjectStyles(e, t, n) {
		let o = this.baseStyle ? this.baseStyle.generateAndInjectStyles(e, t, n) : "";
		{
			let s = "";
			for (let o = 0; o < this.rules.length; o++) {
				const r = this.rules[o];
				if ("string" == typeof r) s += r;
				else if (r) if (ke(r)) {
					const o = r(e);
					"string" == typeof o ? s += o : null != o && !1 !== o && ("object" != typeof o || Array.isArray(o) || Te(o) || le(o) || console.error(`${W(r)} is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.`), s += ae(ze(o, e, t, n)));
				} else s += ae(ze(r, e, t, n));
			}
			if (s) {
				this.dynamicNameCache || (this.dynamicNameCache = /* @__PURE__ */ new Map());
				const e = n.hash ? n.hash + s : s;
				let r = this.dynamicNameCache.get(e);
				if (!r) {
					if (r = V(G(G(this.baseHash, n.hash), s) >>> 0), this.dynamicNameCache.size >= 200) {
						const e = this.dynamicNameCache.keys().next().value;
						void 0 !== e && this.dynamicNameCache.delete(e);
					}
					this.dynamicNameCache.set(e, r);
				}
				if (!t.hasNameForId(this.componentId, r)) {
					const e = n(s, "." + r, void 0, this.componentId);
					t.insertRules(this.componentId, r, e);
				}
				o = ce(o, r);
			}
		}
		return o;
	}
};
var Be = /&/g;
function qe(e, t) {
	let n = 0;
	for (; --t >= 0 && 92 === e.charCodeAt(t);) n++;
	return !(1 & ~n);
}
function He(e) {
	const t = e.length;
	let n = "", o = 0, s = 0, r = 0, i = !1, c = !1;
	for (let a = 0; a < t; a++) {
		const l = e.charCodeAt(a);
		if (0 !== r || i || l !== Re || 42 !== e.charCodeAt(a + 1)) if (i) 42 === l && e.charCodeAt(a + 1) === Re && (i = !1, a++);
		else if (34 !== l && 39 !== l || qe(e, a)) {
			if (0 === r) if (123 === l) s++;
			else if (125 === l) {
				if (s--, s < 0) {
					c = !0;
					let n = a + 1;
					for (; n < t;) {
						const t = e.charCodeAt(n);
						if (59 === t || 10 === t) break;
						n++;
					}
					n < t && 59 === e.charCodeAt(n) && n++, s = 0, a = n - 1, o = n;
					continue;
				}
				0 === s && (n += e.substring(o, a + 1), o = a + 1);
			} else 59 === l && 0 === s && (n += e.substring(o, a + 1), o = a + 1);
		} else 0 === r ? r = l : r === l && (r = 0);
		else i = !0, a++;
	}
	return c || 0 !== s || 0 !== r ? (o < t && 0 === s && 0 === r && (n += e.substring(o)), n) : e;
}
function Ye(e, t) {
	const n = t + " ", o = "," + n;
	for (let s = 0; s < e.length; s++) {
		const r = e[s];
		if ("rule" === r.type) {
			r.value = (n + r.value).replaceAll(",", o);
			const e = r.props, t = [];
			for (let o = 0; o < e.length; o++) t[o] = n + e[o];
			r.props = t;
		}
		Array.isArray(r.children) && "@keyframes" !== r.type && Ye(r.children, t);
	}
	return e;
}
function Ue({ options: e = $, plugins: t = I } = $) {
	let n, s, r;
	const i = (e, t, o) => o.startsWith(s) && o.endsWith(s) && o.replaceAll(s, "").length > 0 ? `.${n}` : e, c = t.slice();
	c.push((e) => {
		e.type === "rule" && e.value.includes("&") && (r || (r = new RegExp(`\\${s}\\b`, "g")), e.props[0] = e.props[0].replace(Be, s).replace(r, i));
	}), e.prefix && c.push(prefixer), c.push(stringify);
	let a = [];
	const l = middleware(c.concat(rulesheet((e) => a.push(e)))), u = (t, i = "", c = "", u = "&") => {
		n = u, s = i, r = void 0;
		const h = function(e) {
			const t = -1 !== e.indexOf("//"), n = -1 !== e.indexOf("}");
			if (!t && !n) return e;
			if (!t) return He(e);
			const o = e.length;
			let s = "", r = 0, i = 0, c = 0, a = 0, l = 0, u = !1;
			for (; i < o;) {
				const t = e.charCodeAt(i);
				if (34 !== t && 39 !== t || qe(e, i)) if (0 === c) if (t === Re && i + 1 < o && 42 === e.charCodeAt(i + 1)) {
					for (i += 2; i + 1 < o && (42 !== e.charCodeAt(i) || e.charCodeAt(i + 1) !== Re);) i++;
					i += 2;
				} else if (40 !== t) if (41 !== t) if (a > 0) i++;
				else if (42 === t && i + 1 < o && e.charCodeAt(i + 1) === Re) s += e.substring(r, i), i += 2, r = i, u = !0;
				else if (t === Re && i + 1 < o && e.charCodeAt(i + 1) === Re) {
					for (s += e.substring(r, i); i < o && 10 !== e.charCodeAt(i);) i++;
					r = i, u = !0;
				} else 123 === t ? l++ : 125 === t && l--, i++;
				else a > 0 && a--, i++;
				else a++, i++;
				else i++;
				else 0 === c ? c = t : c === t && (c = 0), i++;
			}
			return u ? (r < o && (s += e.substring(r)), 0 === l ? s : He(s)) : 0 === l ? e : He(e);
		}(t);
		let d = compile(c || i ? c + " " + i + " { " + h + " }" : h);
		return e.namespace && (d = Ye(d, e.namespace)), a = [], serialize(d, l), a;
	}, h = e;
	let d = M;
	for (let e = 0; e < t.length; e++) t[e].name || v(15), d = G(d, t[e].name);
	return null != h && h.namespace && (d = G(d, h.namespace)), null != h && h.prefix && (d = G(d, "p")), u.hash = d !== M ? d.toString() : "", u;
}
var Je = new Pe(), Xe = Ue(), Ke = import_react.createContext({
	shouldForwardProp: void 0,
	styleSheet: Je,
	stylis: Xe,
	stylisPlugins: void 0
}), Qe = Ke.Consumer;
function Ze() {
	return import_react.useContext(Ke);
}
function et(e) {
	var n;
	const o = Ze(), { styleSheet: s } = o, r = import_react.useMemo(() => {
		let t = s;
		return e.sheet ? t = e.sheet : e.target ? t = t.reconstructWithOptions(void 0 !== e.nonce ? {
			target: e.target,
			nonce: e.nonce
		} : { target: e.target }, !1) : void 0 !== e.nonce && (t = t.reconstructWithOptions({ nonce: e.nonce })), e.disableCSSOMInjection && (t = t.reconstructWithOptions({ useCSSOMInjection: !1 })), t;
	}, [
		e.disableCSSOMInjection,
		e.nonce,
		e.sheet,
		e.target,
		s
	]), i = import_react.useMemo(() => {
		var t;
		return void 0 === e.stylisPlugins && void 0 === e.namespace && void 0 === e.enableVendorPrefixes ? o.stylis : Ue({
			options: {
				namespace: e.namespace,
				prefix: e.enableVendorPrefixes
			},
			plugins: null !== (t = e.stylisPlugins) && void 0 !== t ? t : o.stylisPlugins
		});
	}, [
		e.enableVendorPrefixes,
		e.namespace,
		e.stylisPlugins,
		o.stylis,
		o.stylisPlugins
	]), c = "shouldForwardProp" in e ? e.shouldForwardProp : o.shouldForwardProp, a = null !== (n = e.stylisPlugins) && void 0 !== n ? n : o.stylisPlugins, l = import_react.useMemo(() => ({
		shouldForwardProp: c,
		styleSheet: r,
		stylis: i,
		stylisPlugins: a
	}), [
		c,
		r,
		i,
		a
	]);
	return import_react.createElement(Ke.Provider, { value: l }, e.children);
}
var tt = import_react.createContext(void 0), nt = tt.Consumer;
function ot() {
	const e = import_react.useContext(tt);
	if (!e) throw v(18);
	return e;
}
function st(e) {
	const n = import_react.useContext(tt), o = import_react.useMemo(() => function(e, t) {
		if (!e) throw v(14);
		if (re(e)) {
			const n = e(t);
			if (null === n || Array.isArray(n) || "object" != typeof n) throw v(7);
			return n;
		}
		if (Array.isArray(e) || "object" != typeof e) throw v(8);
		return t ? Object.assign(Object.assign({}, t), e) : e;
	}(e.theme, n), [e.theme, n]);
	return e.children ? import_react.createElement(tt.Provider, { value: o }, e.children) : null;
}
var rt = Object.prototype.hasOwnProperty, it = {};
function ct(e, t) {
	const n = "string" != typeof e ? "sc" : T(e);
	it[n] = (it[n] || 0) + 1;
	const o = n + "-" + z(u + n + it[n]);
	return t ? t + "-" + o : o;
}
var at;
function lt(o, s, r) {
	const i = ie(o), c = o, a = !L(o), { attrs: l = I, componentId: u = ct(s.displayName, s.parentComponentId), displayName: h = B(o) } = s, d = s.displayName && s.componentId ? T(s.displayName) + "-" + s.componentId : s.componentId || u, p = i && c.attrs ? c.attrs.concat(l).filter(Boolean) : l;
	let { shouldForwardProp: f } = s;
	if (i && c.shouldForwardProp) {
		const e = c.shouldForwardProp;
		if (s.shouldForwardProp) {
			const t = s.shouldForwardProp;
			f = (n, o) => e(n, o) && t(n, o);
		} else f = e;
	}
	const m = new Le(r, d, i ? c.componentStyle : void 0);
	function y(o, s) {
		return function(o, s, r) {
			const { attrs: i, componentStyle: c, defaultProps: a, foldedComponentIds: l, styledComponentId: u, target: h } = o, d = import_react.useContext(tt), p = Ze(), f = o.shouldForwardProp || p.shouldForwardProp;
			import_react.useDebugValue && import_react.useDebugValue(u);
			const m = R(s, d, a) || $;
			let y, g;
			{
				const e = import_react.useRef(null), n = e.current;
				if (null !== n && n[1] === m && n[2] === p.styleSheet && n[3] === p.stylis && n[7] === c && function(e, t, n) {
					const o = e, s = t;
					let r = 0;
					for (const e in s) if (rt.call(s, e) && (r++, o[e] !== s[e])) return !1;
					return r === n;
				}(n[0], s, n[4])) y = n[5], g = n[6];
				else {
					y = function(e, t, n) {
						const o = Object.assign(Object.assign({}, t), {
							className: void 0,
							theme: n
						}), s = e.length > 1;
						for (let n = 0; n < e.length; n++) {
							const r = e[n], i = re(r) ? r(s ? Object.assign({}, o) : o) : r;
							for (const e in i) "className" === e ? o.className = ce(o.className, i[e]) : "style" === e ? o.style = Object.assign(Object.assign({}, o.style), i[e]) : e in t && void 0 === t[e] || (o[e] = i[e]);
						}
						return "className" in t && "string" == typeof t.className && (o.className = ce(o.className, t.className)), o;
					}(i, s, m), g = function(e, n, o, s) {
						const r = e.generateAndInjectStyles(n, o, s);
						return import_react.useDebugValue && import_react.useDebugValue(r), r;
					}(c, y, p.styleSheet, p.stylis);
					let n = 0;
					for (const e in s) rt.call(s, e) && n++;
					e.current = [
						s,
						m,
						p.styleSheet,
						p.stylis,
						n,
						y,
						g,
						c
					];
				}
			}
			o.warnTooManyClasses && o.warnTooManyClasses(g);
			const v = y.as || h, S = function(t, n, o, s) {
				const r = {};
				for (const i in t) void 0 === t[i] || "$" === i[0] || "as" === i || "theme" === i && t.theme === o || ("forwardedAs" === i ? r.as = t.forwardedAs : s && !s(i, n) || (r[i] = t[i], s || isPropValid(i) || (at || (at = /* @__PURE__ */ new Set())).has(i) || !L(n) || n.includes("-") || (at.add(i), console.warn(`styled-components: it looks like an unknown prop "${i}" is being sent through to the DOM, which will likely trigger a React console error. If you would like automatic filtering of unknown props, you can opt-into that behavior via \`<StyleSheetManager shouldForwardProp={...}>\` (connect an API like \`@emotion/is-prop-valid\`) or consider using transient props (\`$\` prefix for automatic filtering.)`))));
				return r;
			}(y, v, m, f);
			let b = ce(l, u);
			return g && (b += " " + g), y.className && (b += " " + y.className), S[L(v) && v.includes("-") ? "class" : "className"] = b, r && (S.ref = r), (0, import_react.createElement)(v, S);
		}(g, o, s);
	}
	y.displayName = h;
	let g = import_react.forwardRef(y);
	return g.attrs = p, g.componentStyle = m, g.displayName = h, g.shouldForwardProp = f, g.foldedComponentIds = i ? ce(c.foldedComponentIds, c.styledComponentId) : "", g.styledComponentId = d, g.target = i ? c.target : o, Object.defineProperty(g, "defaultProps", {
		get() {
			return this._foldedDefaultProps;
		},
		set(e) {
			this._foldedDefaultProps = i ? function(e, ...t) {
				for (const n of t) ue(e, n, !0);
				return e;
			}({}, c.defaultProps, e) : e;
		}
	}), _(h, d), g.warnTooManyClasses = ((e, t) => {
		let n = {}, o = !1;
		return (s) => {
			!o && (n[s] = !0, Object.keys(n).length >= 200) && (console.warn(`Over 200 classes were generated for component ${e}${t ? ` with the id of "${t}"` : ""}.\nConsider using the attrs method, together with a style object for frequently changed styles.\nExample:\n  const Component = styled.div.attrs(props => ({\n    style: {\n      background: props.background,\n    },\n  }))\`width: 100%;\`\n\n  <Component />`), o = !0, n = {});
		};
	})(h, d), he(g, () => `.${g.styledComponentId}`), a && se(g, o, {
		attrs: !0,
		componentStyle: !0,
		displayName: !0,
		foldedComponentIds: !0,
		shouldForwardProp: !0,
		styledComponentId: !0,
		target: !0
	}), g;
}
var ut = new Set([
	"a",
	"abbr",
	"address",
	"area",
	"article",
	"aside",
	"audio",
	"b",
	"bdi",
	"bdo",
	"blockquote",
	"body",
	"button",
	"br",
	"canvas",
	"caption",
	"cite",
	"code",
	"col",
	"colgroup",
	"data",
	"datalist",
	"dd",
	"del",
	"details",
	"dfn",
	"dialog",
	"div",
	"dl",
	"dt",
	"em",
	"embed",
	"fieldset",
	"figcaption",
	"figure",
	"footer",
	"form",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"header",
	"hgroup",
	"hr",
	"html",
	"i",
	"iframe",
	"img",
	"input",
	"ins",
	"kbd",
	"label",
	"legend",
	"li",
	"main",
	"map",
	"mark",
	"menu",
	"meter",
	"nav",
	"object",
	"ol",
	"optgroup",
	"option",
	"output",
	"p",
	"picture",
	"pre",
	"progress",
	"q",
	"rp",
	"rt",
	"ruby",
	"s",
	"samp",
	"search",
	"section",
	"select",
	"slot",
	"small",
	"span",
	"strong",
	"sub",
	"summary",
	"sup",
	"table",
	"tbody",
	"td",
	"template",
	"textarea",
	"tfoot",
	"th",
	"thead",
	"time",
	"tr",
	"u",
	"ul",
	"var",
	"video",
	"wbr",
	"circle",
	"clipPath",
	"defs",
	"ellipse",
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence",
	"filter",
	"foreignObject",
	"g",
	"image",
	"line",
	"linearGradient",
	"marker",
	"mask",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialGradient",
	"rect",
	"stop",
	"svg",
	"switch",
	"symbol",
	"text",
	"textPath",
	"tspan",
	"use"
]);
function ht(e, t) {
	const n = [e[0]];
	for (let o = 0, s = t.length; o < s; o += 1) n.push(t[o], e[o + 1]);
	return n;
}
var dt = (e) => (_e.add(e), e);
function pt(e, ...t) {
	if (re(e) || le(e)) return dt(ze(ht(I, [e, ...t])));
	const n = e;
	return 0 === t.length && 1 === n.length && "string" == typeof n[0] ? ze(n) : dt(ze(ht(n, t)));
}
function ft(e, t, n = $) {
	if (!t) throw v(1, t);
	const o = (o, ...s) => e(t, n, pt(o, ...s));
	return o.attrs = (o) => ft(e, t, Object.assign(Object.assign({}, n), { attrs: Array.prototype.concat(n.attrs, o).filter(Boolean) })), o.withConfig = (o) => ft(e, t, Object.assign(Object.assign({}, n), o)), o;
}
var mt = (e) => ft(lt, e), yt = mt;
ut.forEach((e) => {
	yt[e] = mt(e);
});
var gt = class {
	constructor(e, t) {
		this.instanceRules = /* @__PURE__ */ new Map(), this.rules = e, this.componentId = t, this.isStatic = function(e) {
			for (let t = 0; t < e.length; t += 1) {
				const n = e[t];
				if (re(n) && !ie(n)) return !1;
			}
			return !0;
		}(e), Pe.registerId(this.componentId);
	}
	removeStyles(e, t) {
		this.instanceRules.delete(e), this.rebuildGroup(t);
	}
	renderStyles(e, t, n, o) {
		const s = this.componentId;
		if (this.isStatic) {
			if (n.hasNameForId(s, s + e)) this.instanceRules.has(e) || this.computeRules(e, t, n, o);
			else {
				const r = this.computeRules(e, t, n, o);
				n.insertRules(s, r.name, r.rules);
			}
			return;
		}
		const r = this.instanceRules.get(e);
		if (this.computeRules(e, t, n, o), !n.server && r) {
			const t = r.rules, n = this.instanceRules.get(e).rules;
			if (t.length === n.length) {
				let e = !0;
				for (let o = 0; o < t.length; o++) if (t[o] !== n[o]) {
					e = !1;
					break;
				}
				if (e) return;
			}
		}
		this.rebuildGroup(n);
	}
	computeRules(e, t, n, o) {
		const s = ae(ze(this.rules, t, n, o)), r = {
			name: this.componentId + e,
			rules: o(s, "")
		};
		return this.instanceRules.set(e, r), r;
	}
	rebuildGroup(e) {
		const t = this.componentId;
		e.clearRules(t);
		for (const n of this.instanceRules.values()) e.insertRules(t, n.name, n.rules);
	}
};
function vt(e, ...n) {
	const o = pt(e, ...n), s = `sc-global-${z(JSON.stringify(o))}`, r = new gt(o, s);
	_(s);
	const i = (e) => {
		const n = Ze(), i = import_react.useContext(tt);
		let a;
		{
			const e = import_react.useRef(null);
			null === e.current && (e.current = n.styleSheet.allocateGSInstance(s)), a = e.current;
		}
		import_react.Children.count(e.children) && console.warn(`The global style component ${s} was given child JSX. createGlobalStyle does not render children.`), o.some((e) => "string" == typeof e && -1 !== e.indexOf("@import")) && console.warn("Please do not use @import CSS syntax in createGlobalStyle at this time, as the CSSOM APIs we use in production do not handle it well. Instead, we recommend using a library such as react-helmet to inject a typical <link> meta tag to the stylesheet, or simply embedding it manually in your index.html <head> section for a simpler app."), n.styleSheet.server && c(a, e, n.styleSheet, i, n.stylis);
		{
			const o = r.isStatic ? [
				a,
				n.styleSheet,
				r
			] : [
				a,
				e,
				n.styleSheet,
				i,
				n.stylis,
				r
			], l = import_react.useRef(r);
			import_react.useLayoutEffect(() => {
				n.styleSheet.server || (l.current !== r && (n.styleSheet.clearRules(s), l.current = r), c(a, e, n.styleSheet, i, n.stylis));
			}, o), import_react.useLayoutEffect(() => () => {
				n.styleSheet.server || r.removeStyles(a, n.styleSheet);
			}, [
				a,
				n.styleSheet,
				r
			]);
		}
		return n.styleSheet.server && r.instanceRules.delete(a), null;
	};
	function c(e, t, n, o, s) {
		if (r.isStatic) r.renderStyles(e, y, n, s);
		else {
			const c = Object.assign(Object.assign({}, t), { theme: R(t, o, i.defaultProps) });
			r.renderStyles(e, c, n, s);
		}
	}
	return import_react.memo(i);
}
function St(e, t, n, o, s) {
	for (const r in e) {
		const i = e[r], c = s ? s + "-" + r : r;
		if ("object" == typeof i && null !== i) {
			const e = {};
			St(i, t, e, o, c), n[r] = e;
		} else n[r] = o(c, i, r);
	}
}
function bt(e, t, n, o) {
	let s = "";
	for (const r in e) {
		const i = e[r], c = t[r], a = o ? o + "-" + r : r;
		"object" == typeof i && null !== i ? "object" == typeof c && null !== c && (s += bt(i, c, n, a)) : void 0 !== c && "function" != typeof c && (s += "--" + n + a + ":" + c + ";");
	}
	return s;
}
function wt(e, t) {
	var n, o;
	const s = (null !== (n = null == t ? void 0 : t.prefix) && void 0 !== n ? n : "sc") + "-", r = null !== (o = null == t ? void 0 : t.selector) && void 0 !== o ? o : ":root", i = function(e, t) {
		const n = {};
		return St(e, t, n, (e) => "--" + t + e), n;
	}(e, s), c = function(e, t) {
		const n = {};
		return St(e, t, n, (e, n) => {
			{
				const t = String(n);
				let o = 0;
				for (let e = 0; e < t.length && (40 === t.charCodeAt(e) ? o++ : 41 === t.charCodeAt(e) && o--, !(o < 0)); e++);
				0 !== o && console.warn(`createTheme: value "${t}" at "${e}" contains unbalanced parentheses and may break the var() fallback`);
			}
			return "var(--" + t + e + ", " + n + ")";
		}), n;
	}(e, s), a = vt`
    ${r} {
      ${(t) => bt(e, t.theme, s)}
    }
  `;
	return Object.assign(c, {
		GlobalStyle: a,
		raw: e,
		vars: i,
		resolve(t) {
			if (!d) throw new Error("createTheme.resolve() is client-only");
			const n = null != t ? t : document.documentElement;
			return function(e, t, n) {
				const o = {};
				return St(e, t, o, (e, o) => n.getPropertyValue("--" + t + e).trim() || o), o;
			}(e, s, getComputedStyle(n));
		}
	});
}
var Nt;
var Ct = class {
	constructor(e, t) {
		this[Nt] = !0, this.inject = (e, t = Xe) => {
			const n = this.getName(t);
			if (!e.hasNameForId(this.id, n)) {
				const o = t(this.rules, n, "@keyframes");
				e.insertRules(this.id, n, o);
			}
		}, this.name = e, this.id = m + e, this.rules = t, C(this.id), he(this, () => {
			throw v(12, String(this.name));
		});
	}
	getName(e = Xe) {
		return e.hash ? this.name + V(+e.hash >>> 0) : this.name;
	}
};
function Ot(e, ...t) {
	"undefined" != typeof navigator && "ReactNative" === navigator.product && console.warn("`keyframes` cannot be used on ReactNative, only on the web. To do animation in ReactNative please use Animated.");
	const n = ae(pt(e, ...t));
	return new Ct(z(n), n);
}
function Et(e) {
	const n = import_react.forwardRef((n, o) => {
		const s = R(n, import_react.useContext(tt), e.defaultProps);
		return void 0 === s && console.warn(`[withTheme] You are not using a ThemeProvider nor passing a theme prop or a theme in defaultProps in component class "${W(e)}"`), import_react.createElement(e, Object.assign(Object.assign({}, n), {
			theme: s,
			ref: o
		}));
	});
	return n.displayName = `WithTheme(${W(e)})`, se(n, e);
}
Nt = xe;
var At = class {
	constructor({ nonce: e } = {}) {
		this._emitSheetCSS = () => {
			const e = this.instance.toString();
			if (!e) return "";
			const t = this.instance.options.nonce || we();
			return `<style ${ae([
				t && `nonce="${t}"`,
				`${c}="true"`,
				`${l}="${u}"`
			].filter(Boolean), " ")}>${e}</style>`;
		}, this.getStyleTags = () => {
			if (this.sealed) throw v(2);
			return this._emitSheetCSS();
		}, this.getStyleElement = () => {
			if (this.sealed) throw v(2);
			const e = this.instance.toString();
			if (!e) return [];
			const n = {
				[c]: "",
				[l]: u,
				dangerouslySetInnerHTML: { __html: e }
			}, o = this.instance.options.nonce || we();
			return o && (n.nonce = o), [import_react.createElement("style", Object.assign({}, n, { key: "sc-0-0" }))];
		}, this.seal = () => {
			this.sealed = !0;
		}, this.instance = new Pe({
			isServer: !0,
			nonce: e
		}), this.sealed = !1;
	}
	collectStyles(e) {
		if (this.sealed) throw v(2);
		return import_react.createElement(et, { sheet: this.instance }, e);
	}
	interleaveWithNodeStream(e) {
		throw v(3);
	}
};
var Pt = {
	StyleSheet: Pe,
	mainSheet: Je
};
"undefined" != typeof navigator && "ReactNative" === navigator.product && console.warn("It looks like you've imported 'styled-components' on React Native.\nPerhaps you're looking to import 'styled-components/native'?\nRead more about this at https://styled-components.com/docs/basics#react-native");
var _t = `__sc-${c}__`;
"undefined" != typeof window && (window[_t] || (window[_t] = 0), 1 === window[_t] && console.warn("It looks like there are several instances of 'styled-components' initialized in this application. This may cause dynamic styles to not render properly, errors during the rehydration process, a missing theme prop, and makes your application bigger without good reason.\n\nSee https://styled-components.com/docs/faqs#why-am-i-getting-a-warning-about-several-instances-of-module-on-the-page for more info."), window[_t] += 1);
var It = /:(?:(first)-child|(last)-child|(only)-child|(nth-child)\(([^()]+)\)|(nth-last-child)\(([^()]+)\))/g, $t = `:not(style[${c}])`, Rt = `style[${c}]`;
function jt(e) {
	return -1 === e.indexOf("-child") ? e : (It.lastIndex = 0, e.replace(It, (e, t, n, o, s, r, i, c) => t ? `:nth-child(1 of ${$t})` : n ? `:nth-last-child(1 of ${$t})` : o ? `:nth-child(1 of ${$t}):nth-last-child(1 of ${$t})` : s ? -1 !== r.indexOf(" of ") ? e : `:nth-child(${r} of ${$t})` : -1 !== c.indexOf(" of ") ? e : `:nth-last-child(${c} of ${$t})`));
}
function xt(e, t) {
	if (-1 === e.indexOf("+")) return;
	let n = 0, o = 0;
	for (let s = 0; s < e.length; s++) {
		const r = e.charCodeAt(s);
		if (40 === r) n++;
		else if (41 === r) n--;
		else if (91 === r) o++;
		else if (93 === r) o--;
		else if (43 === r && 0 === n && 0 === o && !qe(e, s)) {
			const n = e.substring(0, s), o = e.substring(s + 1);
			t.push(n + "+" + Rt + "+" + o), t.push(n + "+" + Rt + "+" + Rt + "+" + o);
		}
	}
}
function Tt(e) {
	if (e.type === "rule") {
		const t = e.props, n = [];
		for (let e = 0; e < t.length; e++) {
			const o = jt(t[e]);
			n.push(o), xt(o, n);
		}
		e.props = n;
	}
}
//#endregion
export { At as ServerStyleSheet, Qe as StyleSheetConsumer, Ke as StyleSheetContext, et as StyleSheetManager, nt as ThemeConsumer, tt as ThemeContext, st as ThemeProvider, Pt as __PRIVATE__, vt as createGlobalStyle, wt as createTheme, pt as css, yt as default, yt as styled, ie as isStyledComponent, Ot as keyframes, Tt as stylisPluginRSC, ot as useTheme, u as version, Et as withTheme };

//# sourceMappingURL=styled-components.js.map