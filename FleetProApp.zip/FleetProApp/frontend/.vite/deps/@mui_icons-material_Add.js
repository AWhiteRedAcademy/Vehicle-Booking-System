"use client";
import { n as require_jsx_runtime, t as createSvgIcon } from "./createSvgIcon-CRMVhC13.js";
var Add_default = createSvgIcon(/* @__PURE__ */ (0, require_jsx_runtime().jsx)("path", { d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z" }), "Add");
//#endregion
export { Add_default as default };

//# sourceMappingURL=@mui_icons-material_Add.js.map