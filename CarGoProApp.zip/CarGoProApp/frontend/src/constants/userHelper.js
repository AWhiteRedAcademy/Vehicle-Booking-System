export const userIdParam = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
export const userRoleParam = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";